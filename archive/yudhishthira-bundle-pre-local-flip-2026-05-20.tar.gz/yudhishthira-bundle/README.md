# yudhishthira-bundle

Claude Code adaptation of the Yudhishthira data-analyst agent. Drop into any Claude Code project; works standalone or inside the observer-ecosystem.

```
yudhishthira-bundle/
├── README.md                          (this file)
├── install.sh                         minimal installer
├── docs/INSTALL_NOTES.md              detailed install + Hyperagent-vs-Claude-Code notes
├── yudhishthira/
│   ├── agent.md                       identity + posture + Loop + Reconciliation
│   ├── skill.md                       procedures
│   ├── playbook.md                    empty playbook (procedures live here)
│   ├── memories.md                    empty memories (atomic facts live here)
│   └── deliverables/                  per-task .csv + .md land here
└── yudhishthira-hyperagent-prompt.md  original Hyperagent prompt, verbatim
```

## Quick install

```bash
tar -xzf yudhishthira-bundle.tar.gz
cd yudhishthira-bundle
bash install.sh ~/projects/observer-test
```

That copies `yudhishthira/` into `<target>/.claude/agents/`, creates the top-level symlink so `claude --agent yudhishthira` resolves, and creates `<target>/logs/yudhishthira/`.

## What you get

- **Backup guardrail** as the first line of every file-touching task.
- **The Loop**: INSPECT → CLASSIFY → DECLARE FILTERS → COMPUTE → AUDIT → DELIVER.
- **Two-file deliverables**: `.csv` (workflow layer) + `.md` (trust layer) per task.
- **Reconciliation as a first-class task type** with explicit join-key confirmation and `status` column (`match | mismatch | a_only | b_only`).
- **Local playbook** (procedures) and **local memories** (atomic facts), both append-only by entry.
- **No web search, no image gen, no browser** — kept strictly to the analyst role.

## Voice

Direct. Numerate. No filler. Lead with the number, follow with the method. Dharmaraja doesn't guess.

## See also

- `docs/INSTALL_NOTES.md` — full install instructions including the standalone-vs-observer-ecosystem options and Google Sheets setup.
- `yudhishthira-hyperagent-prompt.md` — the original Hyperagent prompt that this Claude Code version adapts. Kept verbatim so the two versions can be cross-referenced.
