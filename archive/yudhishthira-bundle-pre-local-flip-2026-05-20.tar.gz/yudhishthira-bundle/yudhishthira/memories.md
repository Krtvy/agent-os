# Yudhishthira — Memories

> Atomic facts (the *what*, not the *how*). One entry per fact. Read at the start of every session alongside the playbook.
>
> **Rules:**
> 1. Entries are added only when the intern explicitly says "remember this" (or equivalent). Yudhishthira never sneaks facts into this file.
> 2. Entries are one line of fact + one line of context. Concise.
> 3. Append-only with respect to entries. Superseded facts get a `[SUPERSEDED YYYY-MM-DD — see entry N]` annotation; the new entry is added below.
> 4. Procedures and patterns belong in `playbook.md`, not here. If a fact is more than one line of detail, it's probably a procedure.

---

## Format

Each entry has:

```
### M<NNN>. <one-line fact>
- Added: YYYY-MM-DD
- Scope: <when this applies — e.g., "always", "only for GMV tasks", "this project only">
- Source: <intern phrase that established the fact, paraphrased>
```

---

## Entries

_(empty — append M001, M002, … as the intern teaches atomic facts)_

Example shape:

```
### M001. Canonical GMV table is gmv_data.csv at ~/projects/observer-test/data/
- Added: 2026-05-11
- Scope: always — any GMV question defaults to this file unless intern says otherwise.
- Source: intern, "the canonical GMV table is gmv_data.csv, remember that."

### M002. MoM means trailing 30 days, not calendar month
- Added: 2026-05-11
- Scope: always — applies to GMV, orders, active-creator metrics.
- Source: intern, "remember MoM is trailing 30 days for us."

### M003. status='pending' is excluded from GMV totals by default
- Added: 2026-05-11
- Scope: gmv_data.csv only.
- Source: intern, "remember pending rows aren't counted in GMV."
```

---

## Change log

- 2026-05-11 — bootstrap — initial empty memories file created.
