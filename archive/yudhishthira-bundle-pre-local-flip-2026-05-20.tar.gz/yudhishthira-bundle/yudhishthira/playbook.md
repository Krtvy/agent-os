# Yudhishthira — Playbook

> Living procedural reference for Yudhishthira (data analyst). Read at the start of every session. Updated when the intern teaches a new pattern, procedure, or definition.
>
> **Append-only with respect to entries.** Older entries are never deleted; superseded entries are marked `[SUPERSEDED YYYY-MM-DD — see §X]` and the new entry is added below.

---

## File locations

_Canonical file paths and where to find what. Updated as we go._

_(empty — append entries as the intern names files)_

Example shape for entries:

```
- 2026-05-11 — gmv_data_canonical
  Path: ~/projects/observer-test/data/gmv_data.csv
  Source: Kalodata daily export (via nakula kalodata-daily-sync)
  Refreshed: every day ~09:00 IST
  Scope: TikTok Shop GMV, US market, 90-day rolling
```

---

## Canonical schemas

_Column shapes for recurring tables. Source of truth for what each column means and what valid values look like._

_(empty)_

Example shape:

```
- 2026-05-11 — gmv_data.csv schema
  Columns:
    order_id        string, unique
    creator_id      string, FK to creators.csv
    order_date      date (YYYY-MM-DD)
    gmv_usd         float, ≥ 0
    status          enum {active, refunded, cancelled, pending}
    market          enum {US, UK, SG, ID, ...}
  Notes:
    - status='pending' rows are excluded from GMV totals by default.
    - creator_id may be null for legacy orders before 2025-09.
```

---

## Metric definitions

_How metrics are computed in this org. The non-obvious ones._

_(empty)_

Example shape:

```
- 2026-05-11 — MoM (month-over-month)
  Definition: trailing 30 days vs the preceding trailing 30 days,
  not calendar months.
  Rationale: smooths week-ending effects, matches Mayank's weekly review.
  Applies to: GMV, orders, active creators.
```

---

## Recurring task patterns

_When the intern asks for X, the playbook for X._

_(empty)_

Example shape:

```
- 2026-05-11 — Weekly GMV breakdown by creator tier
  Triggered when intern asks: "weekly GMV by tier" or similar.
  Steps:
    1. Load gmv_data.csv (latest snapshot).
    2. Filter: order_date in trailing 7 days, status != 'pending'.
    3. Join on creator_id with creators.csv to get tier.
    4. Groupby tier, sum gmv_usd.
    5. Compare to prior 7-day window for delta.
    6. Deliverable: weekly_gmv_by_tier_<date>.csv + .md.
  Confidence anchors: prior week's value (within 10% expected unless seasonal).
```

---

## Intern conventions

_Naming conventions, output preferences, workflow quirks._

_(empty)_

Example shape:

```
- 2026-05-11 — Filename casing
  All deliverables: snake_case_with_dates.csv (no spaces, no camel case).
  Dates: ISO format (YYYY-MM-DD), not US (MM/DD/YYYY).
```

---

## Open questions

_Things Yudhishthira flagged for the intern to resolve later. Drains as decisions are made._

_(empty)_

---

## Change log

_Append-only record of what was added, when, and by whom._

- 2026-05-11 — bootstrap — initial empty playbook created.
